package com.digishopkart.subscription_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SubscriptionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
